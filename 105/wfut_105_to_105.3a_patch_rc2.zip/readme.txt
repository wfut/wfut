                              ==================
                              Weapons Factory UT
                              ==================

Patch from 105a to 105.3a.

Installation
------------
Extract WFCode.u and WFSystem.u to UT\System, and wfut_readme.htm to 
UT\Help overwriting the older files.


IMPORTANT NOTE FOR SERVER ADMINS
--------------------------------
The connection timouts reffered to in the old 105a readme are wrong, and cause 
the UT creeping ping bug. Better values to use would be something like:

ConnectionTimout=30.0
InitialConnectionTimout=90.0

Setting "InitialConnectionTimout" too low will result in players timing out
before they get a chance to load the current map and enter the game, and setting
it too high results in the UT creeping ping problem. You'll have to tweek
these values a bit to find the right ones for your server.