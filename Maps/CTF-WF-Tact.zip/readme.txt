hahaha

i hope everyone enjoys this map as i made it primarily for this mod...
but itll be out for normal ut ctf soon:)

if you like it allot let me know, email me at--- Millers_The@Hotmail.com
the more mail i get the more i will want to make another map for the mod:)

This is actually the only UT map i have released...
i have made maps for unreal and ut in the past but never released them.

the "UT" version of the map should soon be up at www.zlda.com/ma-runed
and i think ill send it to headshot and mapped and those places too..:)

thankyou for playing my map and have fun!!

oh..and when you play this map with bots you will notice they do not take the tunnels much.
i worked for hours trying to make them do so, but in the end they still go down the middle 
90% of the time.  And yes there are blue paths through the tunnels..so i dunno its weird.
if someone know how to fix this please let me know.
the map should rock with people though..and it is still fun with bots. 

Keith Miller
Millers_The@hotmail.com

---------------------------------------------------------------
you may not tinker with this map without my express permission!!

hey but if you send me mail saying please let me convert it into a map 
for the "___" mod ill probably be willing to chip in let alone give you permission
----------------------------------------------------------------
oh and if you sell this thing ill come and kick you in the balls!!
and if you dont have balls ill seduce you with my charm and take all your profits..lol





